local display = false
local message = ""
local countdown = 0

-- Display banner with countdown
RegisterNetEvent('eas:showBanner')
AddEventHandler('eas:showBanner', function(msg)
    message = msg
    display = true
    countdown = Config.BannerDuration
    Citizen.CreateThread(function()
        while countdown > 0 do
            Citizen.Wait(1000)
            countdown = countdown - 1
        end
        display = false
    end)
end)

-- Drawing the main banner
function drawBanner(text)
    SetTextFont(4)
    SetTextScale(0.5, 0.5)
    SetTextColour(255, 255, 255, 255) -- White text
    SetTextCentre(true)
    SetTextOutline()

    SetTextEntry("STRING")
    AddTextComponentString(text)

    DrawRect(0.5, 0.05, 1.0, 0.06, 255, 0, 0, 180) -- Red background
    DrawText(0.5, 0.03)
end

-- Drawing the countdown text
function drawCountdown(timeLeft)
    SetTextFont(0)
    SetTextScale(0.4, 0.4)
    SetTextColour(255, 255, 255, 200) -- White text with slight transparency
    SetTextCentre(true)
    SetTextOutline()

    SetTextEntry("STRING")
    AddTextComponentString("Goes away in " .. timeLeft .. " seconds")

    DrawText(0.5, 0.08)
end

-- Render the banner and countdown
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if display then
            drawBanner(message)
            drawCountdown(countdown)
        end
    end
end)
