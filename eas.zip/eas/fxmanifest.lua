fx_version 'cerulean'
game 'gta5'

description 'EAS Broadcast Banner'
author 'Editname'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}

server_scripts {
    'server.lua'
}
