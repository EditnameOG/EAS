RegisterCommand('eas', function(source, args, rawCommand)
    local message = table.concat(args, " ")
    if message == "" then
        TriggerClientEvent('chat:addMessage', source, { args = { '^1EAS', 'Please provide a message!' } })
        return
    end

    TriggerClientEvent('eas:showBanner', -1, message)
end, false)
