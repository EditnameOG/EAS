-- Configuration for EAS Broadcast Banner
Config = {}

-- Duration the banner stays on screen (in seconds)
Config.BannerDuration = 15
